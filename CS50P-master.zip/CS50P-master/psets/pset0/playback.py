# https://cs50.harvard.edu/python/2022/psets/0/playback/

text = input("Type something: ").replace(' ', "...")
print(text)
